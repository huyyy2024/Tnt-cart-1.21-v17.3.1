package com.firebow.util;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * Silent rotation — 2-tick Grim-safe pattern.
 *
 * tick N   → setPending(rot)
 * beforeSync (tick N) → applyBeforeSync() → movement packet carries rot
 * tick N+1 → interact → restoreAfterInteract()
 *
 * Fields used: headYaw, bodyYaw (confirmed in Yarn 1.21+build.9).
 * lastBodyYaw / lastHeadYaw do NOT exist in this mapping — not used.
 *
 * v2: thêm getPendingRot() cho KeyboardInputMixin movement fix.
 */
public final class RotationUtil {
    private RotationUtil() {}

    private static volatile float[] pendingRot = null;
    private static volatile float   savedYaw   = 0f;
    private static volatile float   savedPitch = 0f;
    private static volatile boolean hasPending = false;

    public static void setPending(ClientPlayerEntity player, float[] rot) {
        savedYaw   = player.getYaw();
        savedPitch = player.getPitch();
        pendingRot = rot;
        hasPending = true;
    }

    public static boolean applyBeforeSync(ClientPlayerEntity player) {
        if (!hasPending || pendingRot == null) return false;
        applyRaw(player, pendingRot);
        return true;
    }

    public static void restoreAfterInteract(ClientPlayerEntity player) {
        if (player == null) return;
        boolean was = hasPending;
        hasPending = false;
        pendingRot = null;
        if (was) applyRaw(player, new float[]{ savedYaw, savedPitch });
    }

    public static boolean hasPendingRotation() { return hasPending; }

    /** Trả về pending rotation (absolute yaw, pitch) hoặc null nếu không có. */
    public static float[] getPendingRot() { return pendingRot; }

    /**
     * Cập nhật pendingRot với rotation mới (tính lại ở executePending tick N+1).
     * Không đổi savedYaw/savedPitch — restore vẫn về original.
     */
    public static void updatePending(float[] rot) {
        if (hasPending) pendingRot = rot;
    }

    /**
     * Apply rotation trực tiếp ngay bây giờ — dùng khi beforeSync tick này đã qua
     * và cần rotation đúng trước khi interactBlock serialize.
     */
    public static void applyRawNow(ClientPlayerEntity player, float[] rot) {
        applyRaw(player, rot);
    }

    /** Apply pendingRot hiện tại (đã set ở prepareRailPlacement) — không tính lại. */
    public static void applyRawNow(ClientPlayerEntity player) {
        if (pendingRot != null) applyRaw(player, pendingRot);
    }

    public static float[] calcRotation(ClientPlayerEntity player, Vec3d target) {
        return calcRotationFromEye(player.getEyePos(), target);
    }

    /** Tính rotation từ eyePos tuỳ ý — dùng để predict từ eyePos tick N+1. */
    public static float[] calcRotationFromEye(Vec3d eye, Vec3d target) {
        double dx   = target.x - eye.x;
        double dy   = target.y - eye.y;
        double dz   = target.z - eye.z;
        double dist = Math.sqrt(dx * dx + dz * dz);
        float  yaw  = (float)  Math.toDegrees(Math.atan2(-dx, dz));
        float  pitch= (float) -Math.toDegrees(Math.atan2(dy, dist));
        return new float[]{ yaw, pitch };
    }

    public static Vec3d calcHitVec(BlockPos pos, Direction face) {
        return Vec3d.ofCenter(pos).add(
            face.getOffsetX() * 0.4999,
            face.getOffsetY() * 0.4999,
            face.getOffsetZ() * 0.4999
        );
    }

    private static void applyRaw(ClientPlayerEntity player, float[] rot) {
        player.setYaw(rot[0]);
        player.setPitch(rot[1]);
        player.headYaw = rot[0];   // Yarn 1.21+build.9 — confirmed
        player.bodyYaw = rot[0];   // Yarn 1.21+build.9 — confirmed
    }
}
