package com.firebow.mixin;

import com.firebow.event.FireBowRuntime;
import com.firebow.util.BowTrajectoryUtil;
import com.firebow.util.InteractionUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(ClientPlayerEntity.class)
public class ClientPlayerEntityMixin {

    @Unique private boolean firebow$wasUsingBow  = false;
    @Unique private int     firebow$useTimeLeft  = 0;

    /**
     * Phase 2 của 2-tick pattern:
     * beforeSync gọi TRƯỚC khi movement packet gửi đi.
     * RotationUtil.applyBeforeSync() đảm bảo rotation trong packet
     * khớp với hit vector của interactBlock tick sau.
     */
    @Inject(method = "sendMovementPackets", at = @At("HEAD"))
    private void firebow$beforeSync(CallbackInfo ci) {
        FireBowRuntime.get().beforeSync();
    }

    /**
     * Detect bow release → predict landing → store precomputed.
     * Chỉ lưu pos, KHÔNG interact, KHÔNG switch slot ở đây.
     */
    @Inject(method = "tick", at = @At("TAIL"))
    private void firebow$onTick(CallbackInfo ci) {
        FireBowRuntime rt = FireBowRuntime.get();
        if (!rt.isEnabled()) return;

        ClientPlayerEntity self = (ClientPlayerEntity)(Object) this;
        boolean usingBow = self.isUsingItem() && BowTrajectoryUtil.isHoldingBow(self);

        if (usingBow) {
            firebow$wasUsingBow = true;
            firebow$useTimeLeft = self.getItemUseTimeLeft();
        } else if (firebow$wasUsingBow) {
            firebow$wasUsingBow = false;
            int timeLeft = firebow$useTimeLeft;
            firebow$useTimeLeft = 0;

            // Predict từ bow release — chính xác hơn arrow tick
            BlockPos railPos = BowTrajectoryUtil.predictLanding(self, timeLeft);
            if (railPos == null) return;

            // Conservative reach check: cả eyePos tick N và tick N+1 phải trong reach
            // Grim validate với server-side eyePos (lag 1 tick) → dùng max của 2 để safe nhất
            Vec3d eye  = self.getEyePos();
            Vec3d vel  = self.getVelocity();
            double vy  = self.isOnGround() ? vel.y : (vel.y - 0.08) * 0.98;
            Vec3d eyeNext = eye.add(vel.x, vy, vel.z);
            Vec3d center  = Vec3d.ofCenter(railPos);

            double distCur  = eye.squaredDistanceTo(center);
            double distNext = eyeNext.squaredDistanceTo(center);
            if (Math.max(distCur, distNext) > 4.5 * 4.5) return;
            if (distNext < 1.0) return; // quá gần, không cần đặt

            rt.storePrecomputedPos(railPos);
        }
    }
}
